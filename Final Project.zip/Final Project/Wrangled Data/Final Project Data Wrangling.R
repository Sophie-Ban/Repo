#Subset Data

install.packages("tidyr")
library("tidyr")

Mass.Shootings.2019.2 <- Mass.Shootings.2019[1:417, 2:7]

Mass.Shootings.2020.2 <- Mass.Shootings.2020[1:610, 2:7]

US_Gun_Violence_Data.2 <- US_Gun_Violence_Data[1:2930, 2:7]

#Make Histogram for Mental Health Data

#Install Packages
install.packages("ggplot2")
install.packages("datasets")
install.packages("readxl") 
install.packages("dplyr")
install.packages("tidyr") 
install.packages("PerformanceAnalytics")
install.packages("corrplot") 
install.packages("gapminder")
install.packages("gridextra")
install.packages("Ecdat")
install.packages("corpcor")
install.packages("GPArotation")
install.packages("psych")
install.packages("IDPmisc")
install.packages("Lattice") 
install.packages("treetop")
install.packages("scales")
install.packages("rcompanion")
install.packages("gmodels")
install.packages("car")
install.packages("caret")
install.packages("gvlma")
install.packages("predictmeans")
install.packages("caret")
install.packages("magrittr")
install.packages("dplyr")
install.packages("tidyr")
install.packages("lmtest")
install.packages("popbio")
install.packages("e1071")
install.packages("data.table")
install.packages("aptest")
install.packages("ncvtest")
install.packages("effects")
install.packages("multcomp")
install.packages("mvnormtest")

library("ggplot2")

#Make Vector & data frame
year <- c(1982, 1984, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022)
year_df <- data.frame(year)

#create histogram of years
y <- ggplot(year_df, aes(x = year))
y + geom_histogram()
y + geom_histogram(binwidth = 10)
y + geom_histogram(binwidth = 10) +
  ggtitle("Histogram of Mass Shootings w/ Mental Health info over the Years") +
  xlab("Year")

y + geom_histogram(binwidth = 10, fill = "goldenrod", color = "deepskyblue4") +
  ggtitle("Histogram of Mass Shootings w/ Mental Health info over the Years") + xlab("Year")

#Make Histogram for All Shooting Data
#Make Vector & data frame
year <- c(2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022)
year_df <- data.frame(year)

#create histogram of years
y <- ggplot(year_df, aes(x = year))
y + geom_histogram()
y + geom_histogram(binwidth = 15)
y + geom_histogram(binwidth = 15) +
  ggtitle("Histogram of All Shootings 2014 -2021") +
  xlab("Year")

y + geom_histogram(binwidth = 15, fill = "goldenrod", color = "deepskyblue4") +
  ggtitle("Histogram of All Shootings 2014 -2021") + xlab("Year")

shooting_histogram <- ggplot(US_Gun_Violence_Data_Years, aes(x = 2930))
shooting_histogram + geom_histogram(binwidth = 15, fill = "goldenrod", color = "deepskyblue4") +
  ggtitle("Histogram of All Shootings 2014 -2021")

#Create Normal Probability Plot
ggplot(US_Gun_Violence_Data_Years, aes(sample = 2930)) + geom_qq()